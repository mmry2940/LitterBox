import 'package:flutter/material.dart';

class DeviceLogsScreen extends StatelessWidget {
  const DeviceLogsScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text('System logs UI goes here'),
    );
  }
}
